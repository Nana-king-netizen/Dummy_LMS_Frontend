document.addEventListener('DOMContentLoaded', function () {
    const banner = document.querySelector('.banner');
    const images = [
        '5f5279a9-9d23-41bb-ae0c-688fcd63bf39.jpg',
        '5f240369-c72c-40f3-b424-672cbc12545f.jpg',
        '6a4fbcec-91bd-47b2-8ce5-d295b05b36e5.jpg',
        '6cd02ae3-8b01-4f86-862b-ef139bd80b89.jpg'
    ]; // Add your image URLs here
    let imageIndex = 0;

    function showNextImage() {
        if (imageIndex >= images.length) {
            imageIndex = 0;
        }

        const imageUrl = 'url(' + images[imageIndex] + ')';
        banner.style.backgroundImage = imageUrl;

        imageIndex++;
    }

    // Automatic image change every 5 seconds
    setInterval(showNextImage, 5000);

    // Initial image load
    showNextImage();
});
